# 月璃 R7 · v3.0.1

解压整个文件夹后，请阅读 [安装说明](docs/INSTALL.md)。

macOS：依次运行 `install-yue-li-macos.sh` 与 `verify-yue-li-macos.sh`。

Windows：依次运行 `install-yue-li-windows.ps1` 与 `verify-yue-li-windows.ps1`。

本版悬停为“高举星星、保持片刻、收回”。举星保持三帧，共 420 毫秒；单轮仍是 840 毫秒，未修改客户端真实播放倍率。

安装目录为 `pets/yue-li`，升级前会备份已有月璃；原有 `pets/zi-yue` 保留。

[Release 与更新说明](https://github.com/YIFO98/zi-yue-codex-pet/releases/tag/v3.0.1)
