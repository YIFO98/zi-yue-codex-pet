# 月璃 R4 · Yue Li

解压整个目录后，请阅读 [安装说明](docs/INSTALL.md)。

macOS：运行 `install-yue-li-macos.sh`，再运行 `verify-yue-li-macos.sh`。

Windows：运行 `install-yue-li-windows.ps1`，再运行 `verify-yue-li-windows.ps1`。

图集 v2，九组动作及十六个视线方向。新安装目录为 `pets/yue-li`，原有 `pets/zi-yue` 保留。

[项目与完整预览](https://github.com/YIFO98/zi-yue-codex-pet)
